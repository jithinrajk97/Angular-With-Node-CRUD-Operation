import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { DateRangePickerModule } from '@syncfusion/ej2-angular-calendars';
import { FormsModule } from '@angular/forms'; 

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import {HttpHelperService} from '../app/http-helper.service';
import { AddPopupComponent} from '../app/components/add-popup/add-popup.component';
import { UpdatePopupComponent } from './components/update-popup/update-popup.component'

@NgModule({
  declarations: [
    AppComponent,
    AddPopupComponent,
    UpdatePopupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    DateRangePickerModule,
    FormsModule
  ],
  providers: [
    HttpHelperService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
