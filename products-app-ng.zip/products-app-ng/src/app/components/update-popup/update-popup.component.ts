import { Component, OnInit,Input, OnChanges } from '@angular/core';
import { HttpHelperService } from 'src/app/http-helper.service';

@Component({
  selector: 'app-update-popup',
  templateUrl: './update-popup.component.html',
  styleUrls: ['./update-popup.component.scss']
})
export class UpdatePopupComponent implements OnInit,OnChanges {
@Input() updateValue:any;
  name: any;
  brand: any;
  material: any;
  color: any;
  category: any;
  care: any;
  size: any;
  originalPrice: any;
  dryCleanPrice: any;
  lenderPricePerWeek: any;
  ownerPricePerWeek: any;
  finalPricePerWeek: any;
  avialbleDates: any;

  newUpdateValue:any;

  constructor(private httpHelper: HttpHelperService) { }

  ngOnInit(): void {
  }
  ngOnChanges(){
    console.log("vlaues inside comp",JSON.stringify(this.updateValue));
    
  }
  updateProducts() {
    let data:any = {
      name: this.name,
      originalPrice: this.originalPrice,
      totalPrice: this.finalPricePerWeek,
      drycleanPrice: this.dryCleanPrice,
      lendPricePerWeek: this.lenderPricePerWeek,
      ownerPricePerWeeks: this.ownerPricePerWeek,
      brand: this.brand,
      care: this.care,
      category: this.category,
      color: this.color,
      material: this.material,
      size: this.size,
      availableDates: this.avialbleDates
    }

    this.httpHelper.doPatch("http://localhost:3000/products/"+this.updateValue._id, data).subscribe(resp => {
      // let element:HTMLElement = document.getElementById('close-btn') as HTMLElement;
      // element.click();
      window.location.reload();
    }, err => {
      console.log(err)
    });
  }

}
