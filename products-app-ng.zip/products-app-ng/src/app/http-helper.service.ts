import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpHelperService {

  constructor(private http: HttpClient) { }
  doGet(url) {
    return this.http.get(url);
  }

  doPost(url, data) {
    return this.http.post(url, data);
  }
  doPatch(url, data) {
    return this.http.patch(url, data);
  }

  doDelete(url) {
    return this.http.delete(url);
  }
}
