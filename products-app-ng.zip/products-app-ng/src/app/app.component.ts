import { Component, OnInit } from '@angular/core';
import { HttpHelperService } from './http-helper.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})


export class AppComponent implements OnInit {
  title = 'products-app-ng';

  navItems: any = [
    {
      itemName: "Products",
      isActive: true
    },
    {
      itemName: "Category",
      isActive: false
    },
    {
      itemName: "Brand",
      isActive: false
    },
    {
      itemName: "Banner",
      isActive: false
    },
    {
      itemName: "Log out",
      isActive: false
    }
  ];
  products: any = [];
  updateValue: any;
  updateModal1 = null;
  availableDatesUpdate = null;
  public presets = [new Date(), new Date("12/12/2020")];

  constructor(private httpHelper: HttpHelperService) {

  }
  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.httpHelper.doGet("http://localhost:3000/products").subscribe(data => {
      this.products = data;
      console.log("the recieved data is", this.products);
    })
  }

  checkValue(product, value, id) {
    console.log(value)
    this.updateProductdeailsAPICall(product, "http://localhost:3000/products/status/");
  }

  updateProduct(data) {
    console.log(data.availbleDates)
    this.availableDatesUpdate = data.availbleDates;
    this.presets = data.availbleDates;
    this.updateValue = data;
  }

  updateProducts(prDetails) {
    prDetails.availbleDates = [];
    if(this.availableDatesUpdate && this.availableDatesUpdate.start && this.availableDatesUpdate.end) {
      
      prDetails.availbleDates.push(this.availableDatesUpdate.start);
      prDetails.availbleDates.push(this.availableDatesUpdate.end);
    } else if(this.availableDatesUpdate.length == 2){
      prDetails.availbleDates = this.availableDatesUpdate;
    }

    this.updateProductdeailsAPICall(prDetails, "http://localhost:3000/products/");
    
  }


  updateProductdeailsAPICall(prDetails, url) {
    this.httpHelper.doPatch("http://localhost:3000/products/" + prDetails._id, prDetails).subscribe((data) => {
      let element:HTMLElement = document.getElementById('close-btn') as HTMLElement;
      element.click();
      this.products = [];
      this.loadData();
    }, err => {
      console.log(err);
    })
  }

  deleteProduct(product) {
    this.httpHelper.doDelete("http://localhost:3000/products/" + product._id).subscribe((data) => {
      let element:HTMLElement = document.getElementById('close-btn') as HTMLElement;
      element.click();
      this.products = [];
      this.loadData();
    }, err => {
      console.log(err);
    })
  }
  
}
