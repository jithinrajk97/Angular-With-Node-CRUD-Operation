const mongoose = require('mongoose')

const subscriberSchema = new mongoose.Schema(
    {
        status: {
            type: Boolean,
            required: false
        },
        name: {
            type: String,
            required: false
        },

        originalPrice: {
            type: String,
            required: false
        },
        totalPrice: {
            type: String,
            required: false
        },
        drycleanPrice: {
            type: String,
            required: false
        },
        lendPricePerWeek: {
            type: String,
            required: false
        },
        ownerPricePerWeeks  : {
            type: String,
            required: false
        },

        brand: {
            type: String,
            required: false
        },

        care: {
            type: String,
            required: false
        },

        category: {
            type: String,
            required: false
        },
        color: {
            type: String,
            required: false
        },
        material: {
            type: String,
            required: false
        },
        size: {
            type: String,
            required: false
        },
        availbleDates: {
            type: [String],
            required: false
        }
    }
)

module.exports = mongoose.model('inventory', subscriberSchema)