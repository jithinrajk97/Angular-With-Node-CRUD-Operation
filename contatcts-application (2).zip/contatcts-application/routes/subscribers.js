const express = require('express')
const router = express.Router()
const Product = require('../models/subscrber')

router.get('/', async (req, res) => {
    try {
        const subscribers = await Product.find()
        res.json(subscribers)
    } catch (error) {
        res.status(500).json({ message: error.message })
    }
})
router.get('/:id', getSubscriber, (req, res) => {
    res.json(res.subscriber)
})

router.post('/', async (req, res) => {
    console.log("the body is" + req.body);
    const newProducts = new Product({
        status: req.body.status,
        name: req.body.name,
        originalPrice: req.body.originalPrice,
        totalPrice: req.body.totalPrice,
        drycleanPrice: req.body.drycleanPrice,
        lendPricePerWeek: req.body.lendPricePerWeek,
        ownerPricePerWeeks: req.body.ownerPricePerWeeks,
        brand: req.body.brand,
        care: req.body.care,
        category: req.body.category,
        color: req.body.color,
        material: req.body.material,
        size: req.body.size,
        avialbleDates: req.body.availableDates
    })
    try {
        console.log(newProducts.avialbleDates)
        const createdProducts = await newProducts.save();
        res.status(201).json(createdProducts)
    } catch (error) {
        res.status(400).json({ message: error.message })
    }

})
router.patch('/:id', getSubscriber, async (req, res) => {
    if (req.body.name != null) {

        res.subscriber.name = req.body.name
    }
    if (req.body.subscribedToChannel != null) {
        res.subscriber.subscribedToChannel = req.body.subscribedToChannel
    }
    try {
        const updatedSubscrber = await Product.updateOne({ _id: req.body._id }, {
            $set: {
                status: req.body.status,
                name: req.body.name,
                originalPrice: req.body.originalPrice,
                totalPrice: req.body.totalPrice,
                drycleanPrice: req.body.drycleanPrice,
                lendPricePerWeek: req.body.lendPricePerWeek,
                ownerPricePerWeeks: req.body.ownerPricePerWeeks,
                brand: req.body.brand,
                care: req.body.care,
                category: req.body.category,
                color: req.body.color,
                material: req.body.material,
                size: req.body.size,
                availbleDates: req.body.availbleDates
            }
        });
        
        res.json(updatedSubscrber)
    } catch (error) {
        console.log(error)
        res.status(400).json({ message: error.message })

    }
})

router.patch('/status/:id', getSubscriber, async (req, res) => {
    if (req.body.name != null) {

        res.subscriber.name = req.body.name
    }
    if (req.body.subscribedToChannel != null) {
        res.subscriber.subscribedToChannel = req.body.subscribedToChannel
    }
    try {
        const updatedSubscrber = await Product.updateOne({ _id: req.body._id }, {
            $set: {
                status: req.body.status
            }
        });
        
        res.json(updatedSubscrber)
    } catch (error) {
        console.log(error)
        res.status(400).json({ message: error.message })

    }
})

router.delete('/:id', getSubscriber, async (req, res) => {
    console.log("inside delete process");

    try {
        await res.subscriber.remove();
        res.json({ message: "deleted Successfully" })
    } catch (error) {
        res.status(500).json({ message: error.message })

    }
})

async function getSubscriber(req, res, next) {
    let subscriber
    try {
        console.log(" the recieved params inside the update is", req.params.id)
        subscriber = await Product.findById(req.params.id)
        if (subscriber == null) {
            return res.staus(404).json({ message: 'Cannot find the specified Subscriber!!!' })
        }
    } catch (error) {
        return res.staus(500).json({ message: error.message })

    }
    res.subscriber = subscriber
    next()
}

module.exports = router